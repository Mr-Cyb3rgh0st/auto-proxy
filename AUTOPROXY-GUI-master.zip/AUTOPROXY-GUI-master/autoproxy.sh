

sudo python3 /usr/local/bin/main.py

