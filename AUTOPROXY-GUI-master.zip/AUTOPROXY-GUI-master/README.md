# AUTOPROXY-GUI
Automatic Change your ip location in the given time period Using GUI 

OUR YOUTUBE LINK :https://www.youtube.com/channel/UCuafVcvdTEir2jaXW8hhaoQ

<center><img src="screenshot/logo.jpg"></center>


#INSTALL


1.  git clone https://github.com/blackhacker3/AUTOPROXY-GUI.git
2.  chmod +x AUTOPROXY-GUI
3.  cd AUTOPROXY-GUI
4.  sudo bash install.sh
5.  To Launch Tool type "autoprox" in terminal ....



<img src="screenshot/Screenshot from 2020-09-20 02-00-56.png">
<img src="screenshot/Screenshot from 2020-09-20 02-01-08.png">
<img src="screenshot/Screenshot from 2020-09-20 02-01-29.png">
