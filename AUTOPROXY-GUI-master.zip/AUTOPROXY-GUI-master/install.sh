make 
make install 
sudo apt-get install toilet
sudo apt-get install tk
sudo apt-get install xterm
sudo apt-get update
clear
autoprox &

